package com.all.dao;

import org.springframework.stereotype.Repository;

@Repository
public class LocationDAO {

}
