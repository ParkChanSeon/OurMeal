 package com.all.model;

public class Food {
	
	private String fm_code;
	private String fm_name;
	private String fm_image;
	private String fm_info;
	private int fm_price;
	private int fm_kcal;
	private String fm_allergy;
	
	public String getFm_code() {
		return fm_code;
	}
	public void setFm_code(String fm_code) {
		this.fm_code = fm_code;
	}
	public String getFm_name() {
		return fm_name;
	}
	public void setFm_name(String fm_name) {
		this.fm_name = fm_name;
	}
	public String getFm_image() {
		return fm_image;
	}
	public void setFm_image(String fm_image) {
		this.fm_image = fm_image;
	}
	public String getFm_info() {
		return fm_info;
	}
	public void setFm_info(String fm_info) {
		this.fm_info = fm_info;
	}
	public int getFm_price() {
		return fm_price;
	}
	public void setFm_price(int fm_price) {
		this.fm_price = fm_price;
	}
	public int getFm_kcal() {
		return fm_kcal;
	}
	public void setFm_kcal(int fm_kcal) {
		this.fm_kcal = fm_kcal;
	}
	public String getFm_allergy() {
		return fm_allergy;
	}
	public void setFm_allergy(String fm_allergy) {
		this.fm_allergy = fm_allergy;
	}

}
