package com.all.model;

public class Partner {
	
	private String partner_id;
	private String partner_pw;
	private String store_code;
	private String store_title;
	
	public String getPartner_id() {
		return partner_id;
	}
	public void setPartner_id(String partner_id) {
		this.partner_id = partner_id;
	}
	public String getPartner_pw() {
		return partner_pw;
	}
	public void setPartner_pw(String partner_pw) {
		this.partner_pw = partner_pw;
	}
	public String getStore_code() {
		return store_code;
	}
	public void setStore_code(String store_code) {
		this.store_code = store_code;
	}
	public String getStore_title() {
		return store_title;
	}
	public void setStore_title(String store_title) {
		this.store_title = store_title;
	}
	
	

}
