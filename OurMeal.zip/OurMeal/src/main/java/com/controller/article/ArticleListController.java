package com.controller.article;

public class ArticleListController {

}
