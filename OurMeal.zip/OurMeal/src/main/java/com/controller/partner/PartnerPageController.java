package com.controller.partner;

public class PartnerPageController {

}
