package com.controller.partner;

public class partnerRegistController {

}
